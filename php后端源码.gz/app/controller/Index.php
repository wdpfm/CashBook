<?php
namespace app\controller;

use app\BaseController;
use think\facade\Db;


class Index extends BaseController
{
    public function Register($username,$password)
    {
        $res=Db::table('users')->where('username',$username)->find();
        if ($res==null){
        	$data = ['username' => $username, 'password' => $password];
            $userId = Db::name('users')->insertGetId($data);
            return $userId;
		}else
		{
			return 0;//用户已存在
		}
    }
    public function Login($username,$password)
    {
        $res=Db::table('users')->where('username',$username)->find();
        if ($res!=null){
        	if($res['password']==$password){
        		return $res['id'];//登陆成功
        	}else{
        		return -1;//密码错误
        	}
		}else
		{
			return 0;//用户不存在
		}
    }
    public function Upload($uid,$balance)
    {
        $res=Db::table('backup')->where('uid',$uid)->find();
        if ($res!=null){
            Db::table('backup')->where('uid', $uid)->update(['balance' => $balance]);
		}else
		{
		    $data = ['uid' => $uid, 'balance' => $balance];
            Db::name('backup')->insert($data);
		}
            return 1;
    }
    public function Download($uid)
    {
        $res=Db::table('backup')->where('uid',$uid)->find();
        if ($res!=null){
			return $res['balance'];
		}else
		{
			return -1;
		}
    }
}
